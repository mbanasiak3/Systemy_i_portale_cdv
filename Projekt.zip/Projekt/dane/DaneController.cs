    using System.Collections.Generic;
    using Microsoft.AspNetCore.Mvc;

    [Route("api/[controller]")]
    [ApiController]
    public class DaneController : ControllerBase
    {
        private readonly DaneDbContext _dbContext;

        public DaneController(DaneDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Dane>> Get()
        {
            return _dbContext.Dane;
        }
    }
