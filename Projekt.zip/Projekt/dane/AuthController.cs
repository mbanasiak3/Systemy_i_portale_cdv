    using Microsoft.AspNetCore.Mvc;
    using Microsoft.IdentityModel.Tokens;
    using System;
    using System.IdentityModel.Tokens.Jwt;
    using System.Security.Claims;
    using System.Text;

    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginModel model)
        {
            if (!IsValidLogin(model.Email, model.Password))
            {
                return Unauthorized("Nieprawidłowe dane logowania.");
            }

            var token = GenerateJwtToken(model.Email);
            return Ok(new { token });
        }

        private bool IsValidLogin(string email, string password)
        {
            return email == "mbanasiak3@edu.cdv.pl" && password == "Mzlapq10!";
        }

        private string GenerateJwtToken(string email)
        {
            var secretKey = KeyGenerator.GenerateRandomKey(32);
            var key = Encoding.ASCII.GetBytes(secretKey);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Email, email)
                }),
                Expires = DateTime.UtcNow.AddHours(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
