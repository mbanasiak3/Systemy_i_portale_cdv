    public class Dane
    {
        public int Id { get; set; }
        public string Adres_strony { get; set; }
        public string Adres_email_lub_login { get; set; }
        public string Haslo { get; set; }
    }
