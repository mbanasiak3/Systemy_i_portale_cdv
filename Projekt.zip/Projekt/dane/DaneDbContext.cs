    using Microsoft.EntityFrameworkCore;

    public class DaneDbContext : DbContext
    {
        public DbSet<Dane> Dane { get; set; }

        public DaneDbContext(DbContextOptions<DaneDbContext> options)
            : base(options)
        {
        }
    }
