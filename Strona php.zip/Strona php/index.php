<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager haseł</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
    </style>
</head>
<body>

<h1>Manager haseł</h1>

<table>
    <tr>
        <th>ID</th>
        <th>Adres strony</th>
        <th>Adres e-mail lub login</th>
        <th>Hasło</th>
    </tr>

    <?php
$serverName = "manager-hasel-sql-serwer.database.windows.net";
$database = "manager-hasel-sql";
$username = "marta";
$password = "Mzlapq10!";

$conn = new mysqli($serverName, $username, $password, $database);

if ($conn->connect_error) {
    die("Błąd połączenia: " . $conn->connect_error);
}

$sql = "SELECT * FROM Dane";
$result = $conn->query($sql);

echo "<table>
        <tr>
            <th>ID</th>
            <th>Adres Strony</th>
            <th>Adres Email lub Login</th>
            <th>Hasło</th>
        </tr>";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['adres_strony']) . "</td>";
        echo "<td>" . htmlspecialchars($row['adres_email_lub_login']) . "</td>";
        echo "<td>" . htmlspecialchars($row['haslo']) . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>Brak danych w tabeli</td></tr>";
}
echo "</table>";

$conn->close();

</table>

</body>
</html>